package SistemaGestionEstudiantes;

import javax.swing.*;

public class MenuPrincipal extends javax.swing.JFrame {

    public MenuPrincipal() {
        initComponents();
    }

    private void initComponents() {
        setTitle("Menú Principal");
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JMenuBar menuBar = new JMenuBar();
        setJMenuBar(menuBar);

        JMenu reportMenu = new JMenu("Reportes");
        menuBar.add(reportMenu);

        JMenuItem generalReportItem = new JMenuItem("Reporte General");
        generalReportItem.addActionListener(e -> generateGeneralReport());
        reportMenu.add(generalReportItem);

        JMenuItem stateReportItem = new JMenuItem("Reporte por Estado");
        stateReportItem.addActionListener(e -> generateStateReport());
        reportMenu.add(stateReportItem);
    }

    private void generateGeneralReport() {
        String report = GeneradorReportes.generarReporteGeneral();
        JTextArea textArea = new JTextArea(report);
        textArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textArea);

        JFrame reportFrame = new JFrame("Reporte General");
        reportFrame.setSize(400, 300);
        reportFrame.add(scrollPane);
        reportFrame.setVisible(true);
    }

    private void generateStateReport() {
        // Implementa la lógica para generar el reporte por estado
        JOptionPane.showMessageDialog(this, "Generando Reporte por Estado...");
    }

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> new MenuPrincipal().setVisible(true));
    }
}
